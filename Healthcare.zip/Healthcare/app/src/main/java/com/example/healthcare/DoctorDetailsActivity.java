package com.example.healthcare;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class DoctorDetailsActivity extends AppCompatActivity {

    private String [][] doctor_details1 =
            {
                    {"Doctor Name : Ajit Saste", "Hospital Address : Pimpri", "Exp : 5yrs", "Mobile No:9898789878", "600"},
                    {"Doctor Name : Prasad Pawar", "Hospital Address : Delhi", "Exp : 15yrs", "Mobile No:7898789878", "900"},
                    {"Doctor Name : Swapnil kale", "Hospital Address : Mumbai", "Exp : 8yrs", "Mobile No:8898789878", "300"},
                    {"Doctor Name : Deepak Deshmukh", "Hospital Address : Goa", "Exp : 6yrs", "Mobile No:9898789800", "500"},
                    {"Doctor Name : Ashok panda", "Hospital Address : Chennai", "Exp : 7yrs", "Mobile No:9898789868", "800"},
            };
    private String [][] doctor_details2 =
            {
                    {"Doctor Name : Ram", "Hospital Address : Pimpri", "Exp : 5yrs", "Mobile No:9898789878", "600"},
                    {"Doctor Name : Karan", "Hospital Address : Delhi", "Exp : 7yrs", "Mobile No:7898789878", "900"},
                    {"Doctor Name : Alex", "Hospital Address : Mumbai", "Exp : 9yrs", "Mobile No:8898789878", "300"},
                    {"Doctor Name : George", "Hospital Address : Goa", "Exp : 6yrs", "Mobile No:9898789800", "500"},
                    {"Doctor Name : Elvis", "Hospital Address : Chennai", "Exp : 7yrs", "Mobile No:9898789868", "800"},
            };
    private String [][] doctor_details3 =
            {
                    {"Doctor Name : Alby", "Hospital Address : Pimpri", "Exp : 5yrs", "Mobile No:9898789878", "600"},
                    {"Doctor Name : Elina", "Hospital Address : Delhi", "Exp : 17yrs", "Mobile No:7898789878", "900"},
                    {"Doctor Name : Raj", "Hospital Address : Mumbai", "Exp : 11yrs", "Mobile No:8898789878", "300"},
                    {"Doctor Name : Nikhil", "Hospital Address : Goa", "Exp : 8yrs", "Mobile No:9898789800", "500"},
                    {"Doctor Name : Anita", "Hospital Address : Chennai", "Exp : 7yrs", "Mobile No:9898789868", "800"},

            };
    private String [][] doctor_details4 =
            {
                    {"Doctor Name : Peter", "Hospital Address : Pimpri", "Exp : 8yrs", "Mobile No:9898789878", "600"},
                    {"Doctor Name : Percy", "Hospital Address : Delhi", "Exp : 9yrs", "Mobile No:7898789878", "900"},
                    {"Doctor Name : Anastasia", "Hospital Address : Mumbai", "Exp : 10yrs", "Mobile No:8898789878", "300"},
                    {"Doctor Name : Linda", "Hospital Address : Goa", "Exp : 8yrs", "Mobile No:9898789800", "500"},
                    {"Doctor Name : Paddy", "Hospital Address : Chennai", "Exp : 7yrs", "Mobile No:9898789868", "800"},

            };
    private String [][] doctor_details5 =
            {
                    {"Doctor Name : Cairo", "Hospital Address : Pimpri", "Exp : 14yrs", "Mobile No:9898789878", "600"},
                    {"Doctor Name : Alina", "Hospital Address : Delhi", "Exp : 7yrs", "Mobile No:7898789878", "900"},
                    {"Doctor Name : Kristine", "Hospital Address : Mumbai", "Exp : 12yrs", "Mobile No:8898789878", "300"},
                    {"Doctor Name : Diana", "Hospital Address : Goa", "Exp : 8yrs", "Mobile No:9898789800", "500"},
                    {"Doctor Name : Adriana", "Hospital Address : Chennai", "Exp : 9yrs", "Mobile No:9898789868", "800"},

            };
    TextView tv;
    Button btn;
    String[][] doctor_details = {};
    HashMap<String,String> item;
    ArrayList list;
    SimpleAdapter sa;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_details);

        tv = findViewById(R.id.textViewDDTitle);
        btn = findViewById(R.id.buttonCartBack);
        Intent it  = getIntent();
        String title  = it.getStringExtra("title");
        tv.setText(title);

        if (title.compareTo("Family Physicians")==0)
            doctor_details = doctor_details1;
        else
        if (title.compareTo("Dietician")==0)
            doctor_details = doctor_details2;
        else
        if (title.compareTo("Dentist")==0)
            doctor_details = doctor_details3;
        else
        if (title.compareTo("Surgeon")==0)
            doctor_details = doctor_details4;
        else
            doctor_details = doctor_details5;


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               startActivity(new Intent(DoctorDetailsActivity.this,FindDoctorActivity.class));
            }
        });

        list = new ArrayList();
        for (int i =0; i<doctor_details.length;i++){
            item = new HashMap<String,String>();
            item.put("line1", doctor_details[i][0]);
            item.put("line2", doctor_details[i][1]);
            item.put("line3", doctor_details[i][2]);
            item.put("line4", doctor_details[i][3]);
            item.put("line5", "Cons Fees:"+doctor_details[i][4]+"$");
            list.add(item);
        }

        sa = new SimpleAdapter(this,list,
                R.layout.multi_lines,
                new String[]{"line1","line2","line3","line4","line5"},
                new int[]{R.id.line_a, R.id.line_b, R.id.line_c, R.id.line_d,R.id.line_e}
        );

        ListView lst = findViewById(R.id.listViewCart);
        lst.setAdapter(sa);

        lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView,View view ,int i, long l) {
                Intent it = new Intent(DoctorDetailsActivity.this,BookAppointmentActivity.class);
                it.putExtra("text1",title);
                it.putExtra("text2", doctor_details[i][0]);
                it.putExtra("text3", doctor_details[i][1]);
                it.putExtra("text4", doctor_details[i][3]);
                it.putExtra("text5", doctor_details[i][4]);
                startActivity(it);
            }
        });

    }
}